export class kdp_survey{
    user_id!:number;
    delay_insulin!:string;
    insulin_tdm!:string;
    insulin_regardless!:string;
    benifit_insulin!:string;
    receiving_insulin!:string;
    success_insulin!:string;
    notcomplicated_insulin!:string;
    insulin_therapy!:string;
     reluctant_insulin!:string;
    // socioeconomic_level!:string;
    // reluctant_start!:string;
    // years_of_age!:string;
    // cardiovascular!:string;
    // appointment_treatment!:string;
    // excess_weight!:string;
    // staff_notenough!:string; 
    // reluctant_therapy!:string;
    // self_monitoring!:string;
    // not_follow_medical!:string;
    // important_barrier!:string;
     fear_injection!:string;
    // fear_hypoglycemia!:string;
    // cost_insulin!:string;
    // fear_weight!:string;
    // skepticism_insulin!:string;
    // insulin_failure!:string;
    // insulin_worsening!:string;
    // manage_insulin_therapy!:string;
    // threat_qualitye!:string;
     six_months!:string;
     one_to_two_year!:string;
     three_to_five_year!:string;
     five_years!:string;
     people_with_tdm!:string;
     insulin_to_tdmpatients!:string; 
    

}