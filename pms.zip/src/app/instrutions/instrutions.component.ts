import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-instrutions',
  templateUrl: './instrutions.component.html',
  styleUrls: ['./instrutions.component.css']
})
export class InstrutionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
